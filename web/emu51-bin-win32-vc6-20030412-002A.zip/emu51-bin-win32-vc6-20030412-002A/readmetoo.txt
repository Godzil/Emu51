Here are some sample progs for 8051 that run correctly under emu51

p1.asm - simple test appliction
mtask2.asm - switches 2 tasks by using interrupt and a little game with stack :-)